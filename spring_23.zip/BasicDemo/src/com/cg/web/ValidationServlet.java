package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;

@WebServlet("/ValidationServlet")
public class ValidationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    LoginDaoImpl loginDao=null;
    public ValidationServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
		loginDao=new LoginDaoImpl();
		System.out.println("ValidationServlet destroy called");
	}

	public void destroy() {
		System.out.println("ValidationServlet destroy called");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rdSuccess,rdFailure=null;
		PrintWriter out=response.getWriter();
		String unm=request.getParameter("txtUname");
		String pwd=request.getParameter("txtPwd");
		Login user=loginDao.getUserDetails(unm);
		if(unm.equalsIgnoreCase(user.getUsername())&&(pwd.equalsIgnoreCase(user.getPassword())))
		{
			rdSuccess=request.getRequestDispatcher("/SuccessServlet");
			rdSuccess.forward(request, response);
		}
		else
		{
			rdFailure=request.getRequestDispatcher("/FailureServlet");
			rdFailure.forward(request, response);
		}
	}

}
