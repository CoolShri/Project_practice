package com.cg.spring.ui;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;



@SuppressWarnings("deprecation")
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("config2.xml"));
		
		Test t=(Test)factory.getBean("mybean");
		System.out.println("Company Name is :"+t.getCompName());
		System.out.println("Mobile Type is :"+t.getType());
		System.out.println("Mobile Price is :"+t.getPrice());
	}

}
