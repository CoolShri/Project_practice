package com.cg.spring.ui;

public class Test {
	private String compName;
	private String type;
	private int price;
	public Test(String compName, String type, int price) {
		super();
		this.compName = compName;
		this.type = type;
		this.price = price;
	}
	public String getCompName() {
		return compName;
	}
	
	public String getType() {
		return type;
	}
	
	public int getPrice() {
		return price;
	}
	
	
}
