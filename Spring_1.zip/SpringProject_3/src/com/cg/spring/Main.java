package com.cg.spring;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;



public class Main{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("config2.xml"));
		Employee t=(Employee)factory.getBean("emp");
		
		System.out.println("Emp id is "+t.getId());
		System.out.println("Emp name is "+t.getName());
		System.out.println("dept name is "+t.Display());
	}

}






