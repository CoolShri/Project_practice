package com.cg.spring;

public class department {
String dept;

public String getDept() {
	return dept;
}

public void setDept(String dept) {
	this.dept = dept;
}

}
