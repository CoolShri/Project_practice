package com.cg.spring;

public class Employee {
int id;
String name;
department dept;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public department getDept() {
	return dept;
}
public void setDept(department dept) {
	this.dept = dept;
}

public String Display(){
	return dept.getDept();
}
}
