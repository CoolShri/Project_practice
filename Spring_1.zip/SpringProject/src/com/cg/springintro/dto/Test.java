package com.cg.springintro.dto;

public class Test {
	public void display()
	{
		System.out.println("Hello");
	}
}
