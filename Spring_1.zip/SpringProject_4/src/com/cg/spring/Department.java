package com.cg.spring;

import java.util.List;

public class Department {
 private String deptName;
 

private List<Employee>emps;
public List<Employee> getEmps(){
	return emps;
}

public void setEmps(List<Employee>emps)
{
	this.emps = emps;
}

public String getDept() {
	return deptName;
}

public void setDept(String deptName) {
	this.deptName = deptName;
}
public void DisplayDetails()
{
	for(Employee e:emps)
	{
		System.out.println("Employee ID is: "+ e.getEmpid());
		System.out.println("Employee Name is: "+ e.getEmpname());
		System.out.println("Employee Department is: "+ e.Display());
		System.out.println("\n");
	}
}

}
