package com.spring.mvc.dao;

import com.spring.mvc.model.Employee;

public interface IEmployeeDao
{
	void insertEmployee(Employee emp);
	Employee updateEmployee(int id);
	void updatedEmployeeDetails(Employee emp, Employee emps);

}
