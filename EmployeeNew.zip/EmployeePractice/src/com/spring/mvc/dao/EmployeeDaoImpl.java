package com.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Employee;
@Repository
public class EmployeeDaoImpl implements IEmployeeDao 

{
	

    @PersistenceContext
	private EntityManager manager;
	

	@Override
	public void insertEmployee(Employee emp) 
	{
		
		manager.persist(emp);
	}


	@Override
	public Employee updateEmployee(int id) {
		 Employee emps=manager.find(Employee.class, id);
		 return emps;
	}


	@Override
	public void updatedEmployeeDetails(Employee emp, Employee emps) {
		System.out.println(emp.getCity());
		emps.setCity(emp.getCity());
		emps.setDesignation(emp.getDesignation());
		emps.setGender(emp.getGender());
		emps.setName(emp.getName());
		emps.setSalary(emp.getSalary());
		
		manager.merge(emps);
	}

}
