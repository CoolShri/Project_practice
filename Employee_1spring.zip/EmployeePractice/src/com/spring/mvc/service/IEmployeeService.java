package com.spring.mvc.service;

import java.util.List;


import com.spring.mvc.exception.meriException;
import com.spring.mvc.model.Employee;

public interface IEmployeeService {
	public List<Employee> getAll();
	void insertEmployee(Employee emp);
	Employee updateEmployee(int id);
	void updatedEmployeeDetails(Employee emp, Employee emps);
	void deleteEmpById(int id) throws meriException;
}
