package com.spring.mvc.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.IEmployeeDao;
import com.spring.mvc.exception.meriException;
import com.spring.mvc.model.Employee;
@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService
{
	
	@Autowired
	IEmployeeDao empDao;

	@Override
	public void insertEmployee(Employee emp) 
	{
		empDao.insertEmployee(emp);
	}

	@Override
	public Employee updateEmployee(int id) 
	{
		return empDao.updateEmployee(id);	
	}

	@Override
	public void updatedEmployeeDetails(Employee emp, Employee emps) 
	{
		empDao.updatedEmployeeDetails(emp, emps);
		
	}

	@Override
	public void deleteEmpById(int id) throws meriException {
		empDao.deleteEmpById(id);
	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return empDao.getAll();
	}

}
