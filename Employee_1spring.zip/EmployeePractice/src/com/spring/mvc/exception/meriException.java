package com.spring.mvc.exception;

public class meriException extends Exception 
{
	public meriException(String msg1)
	{
		super(msg1);
	}
}
