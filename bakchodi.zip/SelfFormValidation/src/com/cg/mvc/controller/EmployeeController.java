package com.cg.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.mvc.bean.Employee;
import com.cg.mvc.service.IEmpService;

@Controller
public class EmployeeController {
	Employee ee;
	@PersistenceContext
	private EntityManager em; 
	
	
	@Autowired
	IEmpService eSer;
	
	@RequestMapping("/")
	public String showIndex() {
		String view = "index";
		return view;
	}
	@RequestMapping("/home")
	public String showHome() {
		String view = "home";
		return view;
	}
	@RequestMapping("/login")
	public String showLogin(Model model) {
		String view="login";
		model.addAttribute("employee", new Employee());
		return view;
	}
	@RequestMapping("/loginCheck")
	public String doLoginCheck() {
		String view="";
		return view;
	}
	@RequestMapping(value="/showRegistration",method=RequestMethod.GET)
	public String showRegister(Model model,HttpServletRequest req) {
		String view="registration";
		
		
		List<String> list = new ArrayList<>();
		list.add("Mumbai");
		list.add("Chennai");
		list.add("Pune");
		list.add("Banglore");
		ServletContext context = req.getServletContext();
		context.setAttribute("cities", list);
	
		model.addAttribute("employee", new Employee());
		
		return view;
	}
	@RequestMapping(value="/addRegistration",method = RequestMethod.POST)
	public String checkRegister(Model model,@Valid @ModelAttribute("employee")Employee emp,
			 BindingResult result) {
		String view="";
		if(result.hasErrors()) {
			view="registration";
		}
		else {
			view="welcome";
			eSer.addEmployee(emp);
			model.addAttribute("empl", emp);
		}
		return view;
	}
	@RequestMapping("/showUser")
	public String showAllUsers(Model model) {
		String view="showUsers";
		model.addAttribute("empl", eSer.fetchAllEmployee());
		return view;
	}
	
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public String showUpdation(Model model,HttpServletRequest req) {
		String view="updatePage";
		 ee = eSer.check(44);
		if(ee!=null) {
		List<String> list = new ArrayList<>();
		list.add("Mumbai");
		list.add("Chennai");
		list.add("Pune");
		list.add("Banglore");
		ServletContext context = req.getServletContext();
		context.setAttribute("cities", list);
		context.setAttribute("emp", ee);
		model.addAttribute("ee", new Employee());}
		else {
			view="error";
		}
		return view;
	}
	
	@RequestMapping(value="/addUpdate",method = RequestMethod.POST)
	public String doUpdation(Model model,
			@ModelAttribute("ee")Employee ee2,HttpServletRequest req,
			 BindingResult result) {
		String view="welcome";
		ServletContext context = req.getServletContext();
		Employee ee9 = (Employee) context.getAttribute("emp");
		Employee e3 = eSer.updateEmployee(ee9,ee2);
			model.addAttribute("empl", e3);
		//em.merge(emp);
		return view;
	}
	
}
