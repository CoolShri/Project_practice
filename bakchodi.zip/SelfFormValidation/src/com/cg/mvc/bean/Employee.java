package com.cg.mvc.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="empl_tble")

public class Employee {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@NotEmpty(message="Name can not be empty.")
	@Size(min=5,max=20,message="Name can not be less than 5 and greater than 20")
	private String name;
	
	@NotEmpty(message="Designation can not be empty")
	private String designation;
	
	@NotNull
	@Max(value=100000)
	@Min(value=1000)
	private double salary;
	
	@NotEmpty(message="You should select a city.")
	private String city;
	
	/*  @OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	private loginDetails loginD;*/

	@NotEmpty(message="UserName Can not be empty")
	@Pattern(regexp = "([A-Za-z0-9]+)", message="UserName can only be alphanumeric")
	private String userName;
	@NotEmpty(message="Password Can not be empty")
	@Pattern(regexp = "([A-Za-z0-9]+)", message="Password can only be alphanumeric")
	private String password;
	
	public Employee() {
		super();
	}
	public String getUserName() {
		return userName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
/*	public loginDetails getLoginD() {
		return loginD;
	}
	public void setLoginD(loginDetails loginD) {
		this.loginD = loginD;
	}*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation=" + designation + ", salary=" + salary
				+ ", city=" + city + ", userName=" + userName + ", password=" + password + "]";
	}
	
		
	
}
