package com.cg.mvc.bean;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="mvc_logindetails")
public class loginDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@NotEmpty(message="UserName Can not be empty")
	@Pattern(regexp = "([A-Za-z0-9]+)", message="UserName can only be alphanumeric")
	private String userName;
	@NotEmpty(message="Password Can not be empty")
	@Pattern(regexp = "([A-Za-z0-9]+)", message="Password can only be alphanumeric")
	private String password;
	/*
	 @OneToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "user_id", nullable = false)
	 private Employee empl;*/
	public loginDetails() {
		super();
	}
	public loginDetails(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "loginDetails [userName=" + userName + ", password=" + password + "]";
	}
	
	
}
