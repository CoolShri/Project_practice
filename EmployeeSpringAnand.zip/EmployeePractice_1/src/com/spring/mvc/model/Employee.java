package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="yashi")
public class Employee 
{


	public Employee()
	{
		super();
	}
	/*private String name;
	private String designation;
	private String gender;
	private double salary;
	private String city;*/
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int empId;
	@NotEmpty(message="Name can not be empty")
	//@Size(min=3,max=10,message="Name should be in limits")*/
	private String name;
	@NotEmpty(message="Designation can not be empty")
	/*private String companyName;*/
	private String designation;
	@NotEmpty(message="Salary can not be empty")
	private String salary;
	@NotEmpty(message="Please select the city")
	private String  city;
	@NotEmpty(message="Please select the gender")
	private String gender;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	/*public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}*/
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public Employee(int empId, String name, String companyName, String designation, String salary, String city,
			String gender) {
		super();
		this.empId = empId;
		this.name = name;
		/*this.companyName = companyName;*/
		this.designation = designation;
		this.salary = salary;
		this.city = city;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", designation=" + designation + ", salary=" + salary
				+ ", city=" + city + ", gender=" + gender + "]";
	}



	}
	

