package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.transform.impl.AddDelegateTransformer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.mvc.exception.myException;
import com.spring.mvc.model.Employee;
import com.spring.mvc.service.IEmployeeService;

@Controller
public class ControllerPage 
{
	static Employee emps;
	@Autowired
	IEmployeeService empSer;
	
	@RequestMapping("/Homepage")
	public String showHomePage()
	{
		String view="Homepage";
		return view;
	}

	@RequestMapping("/MyregisterPage")
	
		public String showRegister(Model model,HttpServletRequest request)
		{

		model.addAttribute("msg","Welcome To Registration Page");
		model.addAttribute("employee",new Employee());		
		String view="Register";
		List<String>list=new ArrayList<>();
		list.add("Ghaziabad");
		list.add("Lucknow");
		list.add("Mumbai");
		list.add("Pune");
		list.add("Chennai");
		ServletContext context=request.getServletContext();
		context.setAttribute("city",list);
		List<String>list1=new ArrayList<>();
		list1.add("male");
		list1.add("female");
		list1.add("transgender");
		ServletContext context1=request.getServletContext();
		context1.setAttribute("numberlist",list1);
		return view;
		}
	@RequestMapping(value="/Register",method=RequestMethod.POST)
	public String validation(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
		if(bindingResult.hasErrors()) {
			view="Register";
		}
		else
		{
			empSer.insertEmployee(emp);
			ServletContext context1=req.getServletContext();
			context1.setAttribute("employee",emp);
			view="success";
			
			
		}return view;
	}
	
	@RequestMapping("/update")
	public String updateUser(Model model,HttpServletRequest request)
	{
		model.addAttribute("employee",new Employee());
		String view="updatePage";
		model.addAttribute("msg","Welcome To Updation Page");
		return view;
	}
	
	@RequestMapping(value="/updateMyPage",method=RequestMethod.POST)
	public String validateUpdatePage(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req) throws myException
	{
		String view="";
		emps=empSer.updateEmployee(emp.getEmpId());
		if(emps!=null)
		{
		model.addAttribute("employee", new Employee());
		List<String> list=new ArrayList<>();
		list.add("Noida");
		list.add("Ghaziabad");
		list.add("Saharanpur");
		list.add("Meerut");
		list.add("Moradabad");
		ServletContext context1=req.getServletContext();
		context1.setAttribute("cities", list);
		List<String> list2=new ArrayList<>();
		list2.add("male");
		list2.add("female");
		list2.add("others");
		ServletContext context2=req.getServletContext();
		context2.setAttribute("numberList", list2);
		view="employeeDataPage";
		return view;
		}
		else
		{
			throw new myException("Sorry! ID not found");
		}
		
	}
	@RequestMapping(value="/updateEmpPage",method=RequestMethod.POST)
	public String UpdatePage(@Valid @ModelAttribute("employee") Employee emp ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
	
		empSer.updatedEmployeeDetails(emp,emps);
		String view="updateConfirmation";
		model.addAttribute("mymessage","Your Data has been succesfully updated");
		return view;
	
	}
	@RequestMapping("/showall")
	public String UpdatePage111(Model mm,HttpServletRequest req){
		String vv="show";
		List<Employee> qwer = empSer.showAll();
		ServletContext context2=req.getServletContext();
		context2.setAttribute("pp", qwer);
		
		return vv;
	}
	
}
