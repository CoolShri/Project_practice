package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Employee;

public interface IEmployeeService {
	void insertEmployee(Employee emp);
	Employee updateEmployee(int id);
	void updatedEmployeeDetails(Employee emp, Employee emps);
	List<Employee> showAll();

}
