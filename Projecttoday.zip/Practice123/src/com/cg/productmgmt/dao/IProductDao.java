package com.cg.productmgmt.dao;

import java.util.Map;

public interface IProductDao {

	
	public int updateProducts(String Category,int hike);
	public Map<String,String>getProductDetails();
}
