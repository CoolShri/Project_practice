package com.cg.productmgmt.service;

import java.util.Map;

public interface IProductService {

	
	public int updateProducts(String Category,int hike);
	public Map<String,String>getProductDetails();
}
