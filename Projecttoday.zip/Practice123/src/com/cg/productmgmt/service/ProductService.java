package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.util.util;

public class ProductService implements IProductService{

	@Override
	public int updateProducts(String Category, int hike) {
		//calling dao method with dao object
				ProductDAO pdao=new ProductDAO();
		return pdao.updateProducts(Category, hike);
	}

	@Override
	public Map<String, String> getProductDetails() {
		//calling dao method with dao object
		ProductDAO pdao=new ProductDAO();
	
		return 	pdao.getProductDetails();
	}
	public Map<String,Integer>getdetails()
	{	//calling dao method with dao object
		ProductDAO pdao=new ProductDAO();
	
		return pdao.getdetails();
	}
}
