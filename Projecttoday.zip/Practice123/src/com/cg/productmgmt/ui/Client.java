package com.cg.productmgmt.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.service.ProductService;

public class Client {
	static int count;
	
	public static void main(String args[])
	{
		//user interface
		
		Scanner sc=new Scanner(System.in);
while(true)
{
		System.out.println("choose the operation");
		System.out.println("1.Update ProductPrice");
		System.out.println("2.display ProductList");
		System.out.println("3.exit");
	
		System.out.println();

		int chioce=sc.nextInt();
		
		switch(chioce)
		{
		case 1:Update_productPrice();
		break;
		
		case 2:display_productlist();
		break;
		
		case 3:System.exit(0);
		default :System.out.println("********Invalid choice**********");
		}
}
		
	}

	private static void Update_productPrice() {
		Scanner sc=new Scanner(System.in);
		ProductService pser=new ProductService();
		
	Map<String,String> m=new HashMap<>();
	m=pser.getProductDetails();
	  for (Map.Entry<String,String> entry : m.entrySet())  
	  {
          System.out.println(entry.getKey() + 
                           " " + entry.getValue()); 
	  }
	  System.out.println("choose the product to update");

	  System.out.println("1.facepack cosmatic 2. sony electronics 3.samsung electronics 4.pears soap 5.facecream cosmatic 6. lux soap 7.colgate paste");
	  int choice=sc.nextInt();
	  
	  switch(choice){
	  case 1:
		  String key1="facepack";
		  String category1="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike1=sc.nextInt();
	
		  if(hike1>0)
		  {
			int updatedPrice=  pser.updateProducts(category1, hike1);
			System.out.println("Product "+ category1 +" is  updated to "+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  
		  break;
		  
	  case 2:
		  
		  String key2="facepack";
		  String category2="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike2=sc.nextInt();
		  if(hike2>0)
		  {
			int updatedPrice=  pser.updateProducts(category2, hike2);
			System.out.println("Product "+ category2 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
		  
	  case 3:
		  String key3="facepack";
		  String category3="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike3=sc.nextInt();
		  if(hike3>0)
		  {
			int updatedPrice=  pser.updateProducts(category3, hike3);
			System.out.println("Product "+ category3 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
		  
	  case 4:
		  String key4="facepack";
		  String category4="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike4=sc.nextInt();
		  if(hike4>0)
		  {
			int updatedPrice=  pser.updateProducts(category4, hike4);
			System.out.println("Product "+ category4 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
		  
		  
	  case 5:
		  String key5="facepack";
		  String category5="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike5=sc.nextInt();
		  if(hike5>0)
		  {
			int updatedPrice=  pser.updateProducts(category5, hike5);
			System.out.println("Product "+ category5 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
	  case 6:
		  String key6="facepack";
		  String category6="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike6=sc.nextInt();
		  if(hike6>0)
		  {
			int updatedPrice=  pser.updateProducts(category6, hike6);
			System.out.println("Product "+ category6 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
	  case 7:
		  String key7="facepack";
		  String category7="cosmatic";
		  System.out.println("enter the price hike(more than 0)");
		  int hike7=sc.nextInt();
		  if(hike7>0)
		  {
			int updatedPrice=  pser.updateProducts(category7, hike7);
			System.out.println("Product "+ category7 +" is  updated to"+updatedPrice);
			  
		  }
		  else
		  {
			  System.out.println("try again");
		  }
		  break;
		  
	  }
		
	}

	private static void display_productlist() {
		Scanner sc=new Scanner(System.in);
		ProductService pser=new ProductService();
		Map<String,Integer> m=new HashMap<>();
		m=pser.getdetails();
		  for (Map.Entry<String,Integer> entry : m.entrySet())  
		  {
	          System.out.println(entry.getKey() + 
	                           " " + entry.getValue()); 
		  }
		
	}
}
