package com.spring.dao;

import java.util.List;

import com.spring.model.Customer;

public interface CustomerDAO 
{
	public List<Customer> getAll();
	

}
