package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.exception.CustomerException;
import com.spring.model.Customer;
import com.spring.service.CustomerService;

@Controller
public class CustomerController 
{
	@Autowired
	CustomerService service;
	
	@RequestMapping("/home")
	public String showHome()
	{
		return "home";
	}
	@RequestMapping(value="/show")
	public String processShow(Model model) throws CustomerException 
	{
		String view="";
		List<Customer> list = service.getAll();
	  if(list !=null)
	  {
		  model.addAttribute("listCus", list);
		  view="Display";
		  
	  }else
	  {
		  throw new CustomerException("display is not correct");
		  
	  }
	   return view;
	  
	}


}
