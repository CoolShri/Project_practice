package com.spring.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionController
{
	@ExceptionHandler(Exception.class)
	public String handler(Model model,Exception e)
	{
		model.addAttribute("err", e.getMessage());
		return "error";
	}

}
